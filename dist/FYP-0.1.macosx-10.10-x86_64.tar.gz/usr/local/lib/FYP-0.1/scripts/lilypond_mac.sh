#!/usr/bin/env bash
exec "$LILYPOND" "$@"
